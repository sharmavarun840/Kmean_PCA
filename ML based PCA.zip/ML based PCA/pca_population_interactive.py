import os
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import plotly.express as px
import streamlit as st

# Automatically find the CSV file in the script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))
csv_files = [f for f in os.listdir(script_dir) if f.endswith('.csv')]

if not csv_files:
    raise FileNotFoundError("No CSV files found in the directory.")

# Load the first CSV file found
file_path = os.path.join(script_dir, csv_files[0])
df = pd.read_csv(file_path)

# Try to identify the population column and frequency columns
potential_pop_columns = ['Population', 'population', 'Group', 'group']
population_column = None

for col in potential_pop_columns:
    if col in df.columns:
        population_column = col
        break

if not population_column:
    raise ValueError("No population column found in the CSV file.")

# Extract populations and frequencies
populations = df[population_column]
frequencies = df.drop(columns=[population_column])

# Standardize the frequencies
scaler = StandardScaler()
scaled_frequencies = scaler.fit_transform(frequencies)

# Perform PCA
pca = PCA(n_components=2)  # Reduce to 2 components for visualization
principal_components = pca.fit_transform(scaled_frequencies)

# Create a DataFrame with the principal components
pca_df = pd.DataFrame(data=principal_components, columns=['PC1', 'PC2'])
pca_df['Population'] = populations

# Fit a KMeans clustering model
kmeans = KMeans(n_clusters=3)  # Adjust the number of clusters as needed
kmeans.fit(principal_components)
pca_df['Cluster'] = kmeans.labels_

# Plot the PCA results interactively using Plotly
fig = px.scatter(pca_df, x='PC1', y='PC2', color='Population', symbol='Cluster',
                 labels={'PC1': 'Principal Component 1', 'PC2': 'Principal Component 2'},
                 hover_data=['Population', 'Cluster'])

# Update layout to remove legend background and ensure the plot is colorful
fig.update_layout(
    title='',
    autosize=False,
    width=1000,
    height=600,
    margin=dict(l=50, r=50, b=50, t=50),
    legend=dict(
        x=1.05,
        y=1,
        traceorder='normal',
        font=dict(
            family="sans-serif",
            size=12,
            color="black"
        ),
        bgcolor='rgba(0,0,0,0)',  # Transparent background
        bordercolor="Black",
        borderwidth=2
    )
)

# Add the Streamlit interface
st.set_page_config(page_title="PCA and Clustering Dashboard", layout="wide")
st.title("Interactive PCA and Clustering Dashboard")
st.plotly_chart(fig)

# Display the PCA DataFrame
st.header("PCA Data")
st.dataframe(pca_df)

# Download Button
st.sidebar.title("Download Plot")
st.sidebar.write("Download the plot in high definition:")
download_button = st.sidebar.button("Download Plot as PNG")

if download_button:
    fig.write_image("pca_plot.png", format="png", width=1200, height=800, scale=3)  # Ensure high resolution
    with open("pca_plot.png", "rb") as file:
        btn = st.sidebar.download_button(
            label="Download PCA Plot",
            data=file,
            file_name="pca_plot.png",
            mime="image/png"
        )

# Instructions to run the Streamlit app
st.sidebar.title("Instructions")
st.sidebar.write("""
1. Ensure you have Streamlit installed: `pip install streamlit`
2. Save this script as `pca_population_interactive.py` in the directory with the CSV files
3. Run the script using: `streamlit run pca_population_interactive.py`
""")
